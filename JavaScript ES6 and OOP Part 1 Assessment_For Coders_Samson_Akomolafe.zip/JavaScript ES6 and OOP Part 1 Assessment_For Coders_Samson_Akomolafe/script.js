const recipes = [];
const editIndexOfItem = null;

document.getElementById('add-recipe-button').addEventListener('click', () => {
    const title = document.getElementById('title').value;
    const ingredients = document.getElementById('ingredients').value;
    const instructions = document.getElementById('instructions').value;

    if (editIndexOfItem !== null) {
        updateRecipe(editIndexOfItem, title, ingredients, instructions);
    } else {
        addRecipe(title, ingredients, instructions);
    }

    clearInputFields();
    displayRecipes();
});

function addRecipe(title, ingredients, instructions) {
    const newRecipe = { title, ingredients, instructions };
    recipes.push(newRecipe);
}

function updateRecipe(index, title, ingredients, instructions) {
    recipes[index] = { title, ingredients, instructions };
    editIndexOfItem = null;
}

function clearInputFields() {
    document.getElementById('title').value = '';
    document.getElementById('ingredients').value = '';
    document.getElementById('instructions').value = '';
}

function displayRecipes() {
    const recipeList = document.getElementById('recipe-list');
    recipeList.innerHTML = '';

    recipes.forEach((recipe, index) => {
        const recipeItem = document.createElement('li');

        recipeItem.innerHTML = `
            <h3>${recipe.title}</h3>
            <p><strong>Ingredients:</strong> ${recipe.ingredients}</p>
            <p><strong>Instructions:</strong> ${recipe.instructions}</p>
            <button onclick="editRecipe(${index})">Edit</button>
            <button onclick="deleteRecipe(${index})">Delete</button>
        `;

        recipeList.appendChild(recipeItem);
    });
}

function editRecipe(index) {
    const recipe = recipes[index];
    document.getElementById('title').value = recipe.title;
    document.getElementById('ingredients').value = recipe.ingredients;
    document.getElementById('instructions').value = recipe.instructions;
    editIndexOfItem = index;
}

function deleteRecipe(index) {
    recipes.splice(index, 1);
    displayRecipes();
}
