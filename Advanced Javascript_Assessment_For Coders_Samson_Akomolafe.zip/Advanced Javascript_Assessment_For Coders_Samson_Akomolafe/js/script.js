// Function to handle user registration
function register() {
  const userData = fetchRegisterPageData();

  // Validate userData
  if (userData.password !== userData.confirmPassword) {
    document.getElementById("message").textContent = "Passwords do not match!";
    return;
  }

  // Check if user already exists
  const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
  if (existingUsers.find(user => user.username === userData.username)) {
    document.getElementById("message").textContent = "Username already exists!";
    return;
  }

  // Save user data to local storage
  existingUsers.push({
    fullname: userData.fullname,
    username: userData.username,
    email: userData.email,
    contact: userData.contact,
    password: userData.password
  });
  localStorage.setItem('users', JSON.stringify(existingUsers));

  // Handle successful registration
  console.log('Registration successful:', userData);
  window.location.href = 'signin.html';
}

// Fetch form data from the register.html page
function fetchRegisterPageData() {
  const fullname = document.getElementById("fullname").value;
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const contact = document.getElementById("contact").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirm-password").value;

  return { fullname, username, email, contact, password, confirmPassword };
}

// Function to handle user login
function signIn() {
  const loginData = fetchSignInPageData();
  const existingUsers = JSON.parse(localStorage.getItem('users')) || [];

  // Check if user exists and password is correct
  const user = existingUsers.find(user => user.username === loginData.username);
  if (!user || user.password !== loginData.password) {
    document.getElementById("message").textContent = "Login failed: Invalid credentials";
    return;
  }

  // Handle successful login
  console.log('Login successful:', user);
  sessionStorage.setItem("login", JSON.stringify(user));
  window.location.href = 'index.html'; // Redirect to main page
}

// Function to fetch user data from the signin.html page
function fetchSignInPageData() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  return { username, password };
}

// Function to load content on the index.html page
function loadContent() {
  const userLogin = sessionStorage.getItem("login");

  if (userLogin) {
    fetchAndLoadData();
  } else {
    loadSignInPage();
  }
}

// Fetch the URLs from the external API
function fetchURLs() {
  const cuisineUrl = "https://foodorder-api-elti.onrender.com/v1/cuisines";
  const categoryUrl = "https://foodorder-api-elti.onrender.com/v1/categories";
  const restaurantUrl = "https://foodorder-api-elti.onrender.com/v1/restaurants";
  return { cuisineUrl, categoryUrl, restaurantUrl };
}

// Get the list HTML elements to display cuisines, categories and restaurants
function loadListElements() {
  const cuisineList = document.getElementById("cuisine-list");
  const categoryList = document.getElementById("category-list");
  const restaurantList = document.getElementById("restaurant-list");
  return { cuisineList, categoryList, restaurantList };
}

// Fetch and load data from the URLs
function fetchAndLoadData() {
  const { cuisineUrl, categoryUrl, restaurantUrl } = fetchURLs();
  const { cuisineList, categoryList, restaurantList } = loadListElements();

  fetchData(cuisineUrl, cuisineList);
  fetchData(categoryUrl, categoryList);
  fetchData(restaurantUrl, restaurantList);
}

// Load the signin.html page
function loadSignInPage() {
  window.location.href = "../html/signin.html";
}

// Function to fetch data from an external URL endpoint
async function fetchData(url, listElement) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Network response was not ok');
    const data = await response.json();
    displayData(data, listElement);
  } catch (error) {
    console.error('Fetch error:', error);
    listElement.innerHTML = '<li>Error fetching data</li>'; // Display error message
  }
}

// Function to fetch data from an external URL endpoint
async function fetchData(url, listElement) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Network response was not ok');
    
    const data = await response.json();
    
    // Display welcome message if user is logged in
    const userLogin = sessionStorage.getItem("login");
    if (userLogin) {
      const user = JSON.parse(userLogin);
      const userNameElement = document.getElementById("user-name");
      if (userNameElement) {
        userNameElement.textContent = `Welcome, ${user.fullname}`;
      }
    }

    // Call displayData to handle displaying the fetched data
    displayData(data, listElement);
  } catch (error) {
    console.error('Fetch error:', error);
    listElement.innerHTML = '<li>Error fetching data</li>'; // Display error message
  }
}

// Display data which is fetched from an external API
function displayData(data, listElement) {
  // Clear any existing content in the list element
  listElement.innerHTML = '';

  // Check if data is an array and has items
  if (Array.isArray(data) && data.length > 0) {
    data.forEach(item => {
      // Create a new list item for each element in the data
      const listItem = document.createElement('li');
      listItem.textContent = item.name; // Assuming each item has a 'name' property
      // You can customize this to display other properties as needed
      listElement.appendChild(listItem);
    });
  } else {
    // If no data, display a message
    const messageItem = document.createElement('li');
    messageItem.textContent = 'No data available';
    listElement.appendChild(messageItem);
  }
}

// Logging out when clicked on the logout button
function logout() {
  // Clear user login data from session storage
  sessionStorage.removeItem("login");

  // Optionally, you can clear any other relevant session data here

  // Redirect to the sign-in page
  window.location.href = 'signin.html';
}