// 1. Define 2 functions
// 1st function named as checkEven which will check if the num passed is even or not.
// 2nd function named as filterEvens which will take an array of numbers and the checkEven function as arguments.
// This filterEvens function will filter out  only even numbers using the checkEven function and generate a new array of the even numbers.

// 1st function to check if a number is even
function checkEven(num) {
    return num % 2 === 0;
}

// 2nd function to filter even numbers from an array
function filterEvens(numbers, checkFunction) { // filter with the provided check function
    
    return numbers.filter(checkFunction);
}

// Sample Array
const numbersArray = [2, 5, 6, 4, 9, 11, 12, 14, 13, 17];
const evenNumbers = filterEvens(numbersArray, checkEven);

console.log(evenNumbers); 

//2. Write an IIFE that calculates the factorial of a given number and immediately logs the result to the console.

(function factorial(n) {
    if (n < 0) {
        console.log("Factorial is not defined for negative numbers.");
        return;
    }
    if (n === 0 || n === 1) {
        console.log(1);
        return;
    }
    
    
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    
    console.log(result);
})(7); 

//3. The product1 object (which is already given) consists of title, price and category information of Nike Shoes.
// The description() function describes the product using its properties.
// Your task is to create a product2 object which consists of the title, price and category information of Sony TV.
// Next, use the call() method to invoke the description() method of product1 on product2.
// This should display the details of product2 on the console. 
var product1 = {
    title: "Nike Shoes",
    price: 300,
    category: "Shoes",
    description: function() {
        console.log(`Title: ${this.title}`);
        console.log(`Price: $${this.price}`);
        console.log(`Category: ${this.category}`);
    }
}

// Create product2 object
var product2 = {
    title: "Sony 75-inch TV",
    price: 1200,
    category: "Electronics"
};

// Using call() to invoke the description method of product1 for product2
product1.description.call(product2);

//4. Given an array of person objects, define a function to find oldest person object.

// Array of person objects
persons = [
    {"name" : "Harry", "age" : 38}, 
    {"name" : "Ron", "age" : 65}, 
    {"name" : "Hermione", "age" : 13}]

// Function to find the oldest person
function findOldestPerson(personsArray) {
    return personsArray.reduce((oldest, current) => {
        return (current.age > oldest.age) ? current : oldest;
    });
}

// Run
const oldestPerson = findOldestPerson(persons);
console.log(oldestPerson);


//5.  Create a function that calculates the sum of an array using IIFE function and returns it.

var sumArray = (function(arr) {
    return arr.reduce((sum, current) => sum + current, 0);
})([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]); //calculate the sum of a different set of numbers

console.log(sumArray);

/*6. Write a function printContext that, when invoked, logs the this keyword to the console. 
Then, demonstrate how the context of a function can change when calling it with different objects using the call method.*/

function printContext() {
    console.log(this);
}

// Creating two objects
var obj1 = { name: "Samson" };
var obj2 = { name: "Akomolafe" };

// Invoking printContext 
printContext(); 
printContext.call(obj1); // Using call() to invoke printContext with obj1 as context
printContext.call(obj2); // Using call() to invoke printContext with obj2 as context

//7. Create a function multiply that takes two parameters and returns their product. Use the bind method to create a new function "double" that multiplies a single parameter by 2.

// Function that multiplies two numbers
function multiply(a, b) {
    return a * b;
}

// new function that "double"  by using bind to set the first parameter to 2
var doublethenum = multiply.bind(null, 2);

// Using the double function
console.log(doublethenum(10));
console.log(doublethenum(20));

/* 8. Create an object person with properties name and age. Write a function "introduce" that logs a message introducing the person. 
Then, use the call method to invoke the introduce function with the person object as the context.*/

// Create the person object
var personObject = {
    name: "Great Learning",
    age: 15
};

// Define the introduce function
function introduce() {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
}

// Use call() to invoke introduce with person as context
introduce.call(personObject);

// 9. Write a higher order function createMultiplier that takes a factor as an argument and returns another functiom that multiplies a number by that factor. 

// Higher-order function that creates a multiplier
function createMultiplier(factor) {
    return function(number1) {
        return number1 * factor;
    };
}

// Samples
const double = createMultiplier(2); // Creates a function to double a number
const triple = createMultiplier(3); // Creates a function to triple a number

console.log(double(10)); 
console.log(double(20)); 
console.log(triple(30)); 
console.log(triple(40));

/* 10. Write a function called "calculate" that adds two numbers and assign a property "description" to it with a string describing what the function does. 
Then, access and log this property.*/

function calculate(a, b) { //function to add 2 numbers 
    return a + b;
}

// Assign a description property to the function
calculate.description = "This function - (function calculate() adds two numbers together.";

// Access and log the description property
console.log(calculate.description);
