//Problem Statement 1
class Stack {
  constructor() {
    this.items = []; // Initialize an empty array to store stack elements
  }

  isEmpty() {
    return this.items.length === 0; // Check if the stack is empty
  }

  push(element) {
    this.items.push(element); // Add the specified element to the end of the items array
  }

  pop() {
    if (this.isEmpty()) {
      return "Underflow"; // Check if the stack is empty
    }
    return this.items.pop(); // Remove and return the last element of the items array
  }

  peek() {
    if (this.isEmpty()) {
      return "Stack is empty"; // Handle case when stack is empty
    }
    return this.items[this.items.length - 1]; // Return the last element without removing it
  }

  printStack() {
    return this.items.join(' '); // Return the resulting string with trailing spaces removed
  }
}

// Create a new stack instance
const stack = new Stack();

// Push elements onto the stack
stack.push(10);
stack.push(20);
stack.push(30);

// Check if the stack is empty
console.log("Is stack empty:", stack.isEmpty()); // Output: false

// Print the stack elements
console.log("Stack elements:", stack.printStack()); // Output: "10 20 30"

// Pop an element from the stack
console.log("Popped element:", stack.pop()); // Output: 30

// Peek the top element of the stack
console.log("Top element:", stack.peek()); // Output: 20

//-----------------------------------------------------------------------------

//Problem Statement 2
function isBalanced(expression) {
  const stack = new Stack(); // Initialize an empty stack

  for (let i = 0; i < expression.length; i++) {
    const char = expression[i];

    if (char === '(' || char === '{' || char === '[') {
      stack.push(char); // If it's an opening brace, push it onto the stack
    } else if (char === ')' || char === '}' || char === ']') {
      if (stack.isEmpty() || !isMatchingPair(stack.pop(), char)) {
        return false; // Check if the stack is empty or if the braces don't match
      }
    }
  }

  return stack.isEmpty(); // If the stack is empty at the end, the expression is balanced
}

function isMatchingPair(opening, closing) {
  return (opening === '(' && closing === ')') ||
         (opening === '{' && closing === '}') ||
         (opening === '[' && closing === ']'); // Check if the braces form a matching pair
}

// Example usage:
let balancedExpression = "{(a+b)-c}*[a-{b*c}]";
let unbalancedExpression = "{(a+b-c}*[a-{b*c}]";

console.log("Balanced Expression:", isBalanced(balancedExpression)); // Output: true
console.log("Balanced Expression:", isBalanced(unbalancedExpression)); // Output: false
