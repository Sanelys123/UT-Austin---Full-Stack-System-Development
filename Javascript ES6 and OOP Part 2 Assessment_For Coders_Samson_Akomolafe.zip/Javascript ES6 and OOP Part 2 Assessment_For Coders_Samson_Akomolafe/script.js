// Function to handle club card click
function handleClubClick(cardElement) {
    const clubName = cardElement.querySelector('.club-name').textContent;
    const clubDetails = footballClubs.find(club => club.name === clubName);
    if (clubDetails) {
      displayClubDetails(clubDetails);
    }
  }
  
  // Function to display club details
  function displayClubDetails(footballClub) {
    const detailsSection = document.getElementById('club-details');
    detailsSection.innerHTML = `
      <h2>${footballClub.name}</h2>
      <img src="${footballClub.image}" alt="${footballClub.name} Logo">
      <p>League: ${footballClub.league}</p>
      <p>City: ${footballClub.city}</p>
      <p>Stadium: ${footballClub.stadium}</p>
      <p>${footballClub.description}</p>
      <button onclick="displayClubs()">Back</button>
      <button onclick="viewClubPlayers('${footballClub.name}')">View Players</button>
    `;
  }
  
  // Function to view club players
  function viewClubPlayers(clubName) {
    const clubDetails = footballClubs.find(club => club.name === clubName);
    if (clubDetails) {
      const playersSection = document.getElementById('players-details');
      playersSection.innerHTML = `
        <button onclick="displayClubs()">Back</button>
        <h3>Players of ${clubDetails.name}</h3>
        <ul>
          ${clubDetails.players.map(player => `
            <li>${player.name} - Position: ${player.position}, Goals: ${player.goals}, Assists: ${player.assists}</li>
          `).join('')}
        </ul>
      `;
    }
  }
  
  // Function to handle search input
  function handleSearchInput() {
    const searchInput = document.getElementById('search-box').value.toLowerCase();
    const filteredClubs = footballClubs.filter(club =>
      club.name.toLowerCase().includes(searchInput) ||
      club.city.toLowerCase().includes(searchInput) ||
      club.league.toLowerCase().includes(searchInput)
    );
    displayClubs(filteredClubs);
  }
  
  // Function to display clubs
  function displayClubs(clubs = footballClubs) {
    const clubsSection = document.getElementById('clubs');
    clubsSection.innerHTML = clubs.map(club => `
      <div class="club-card" onclick="handleClubClick(this)">
        <h3 class="club-name">${club.name}</h3>
        <img src="${club.image}" alt="${club.name} Logo">
        <p>League: ${club.league}</p>
        <p>City: ${club.city}</p>
        <button>View Players</button>
      </div>
    `).join('');
  }
  
  // Initial display of all clubs
  displayClubs();