// This function should retrieve all the project objects from projects array.
// It should then traverse over the array to create individual cards displaying each project details.
   // Write your code here
  // Load projects from the projects array
  function loadProjects() {
      const projectsList = document.getElementById('projects-list');
      projectsList.innerHTML = ''; // Clear existing projects
  
      projects.forEach(project => {
          const projectItem = document.createElement('section');
          projectItem.classList.add('project-item');
  
          projectItem.innerHTML = `
              <h3>${project.title}</h3>
              <p>${project.description}</p>
              <img src="${project.image}" alt="${project.title}">
          `;
  
          projectsList.appendChild(projectItem);
      });
  }
      
  // Call loadProjects on page load to display existing projects
  window.onload = loadProjects;

// This function should return the projectId of the new project
function newProjectId(){
 // Write code to create and return new Project Id
return projects.length === 0 ? 1 : Math.max(...projects.map(project => project.id)) + 1;

}

function saveNewProject() {

  // Write your code here
document.getElementById('submit').addEventListener('click', function() {
  const title = document.getElementById('project-title').value;
  const description = document.getElementById('project-description').value;
  const imageURL = document.getElementById('project-image').value;

  if (title && description && imageURL) {
      // Create a new project object
    const newProjectId = {
        title: title,
        description: description,
        image: imageURL
  };

  // Add the new project to the projects array (optional if you want to keep it in memory)
    projects.push(newProjectId);
     
  // Clear the input fields after saving
    document.getElementById('project-title').value = '';
    document.getElementById('project-description').value = '';
    document.getElementById('project-image').value = '';

  } else {
        alert('Please fill in all fields.');
    }


    // Update the UI
  loadProjects();

});

}
