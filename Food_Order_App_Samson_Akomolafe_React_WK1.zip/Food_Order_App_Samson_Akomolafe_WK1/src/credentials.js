export const credentials = {
    "harry1992": "harrypotter1992",
    "ron1993": "ronweasley1993",
    "sam2024": "samakoh2024",
    "sam2024a": "samakoh2024a"
    
}

