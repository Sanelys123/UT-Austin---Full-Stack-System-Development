import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import ItemCard from "../../components/ItemCard.js";
import categories from "../../categories.js";
import cuisines from "../../cuisines.js";
import restaurants from "../../restaurants.js";

const AdminDashboard = () => {
  return (
    <>
      <Container>
        <h2 className="md-auto text-center p-4">Admin Dashboard</h2>
        <Row className="mb-3">
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Cuisines</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                View Cusine
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                Add Cuisine
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Categories</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Categories
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Categories
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Restaurants</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Restaurants
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Restaurants
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Food Items</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Food Items
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Food Items
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Food Orders</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Food Orders
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Food Orders
                </Button>
              </Card.Body>
            </Card>
          </Col>
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Users</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Users
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Users
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col className="mb-3">
            <Card border="secondary">
              <Card.Body>
                <Card.Title as="h4">Restaurants Menu</Card.Title>
                <Button variant="outline-info" size="sm" className="me-3">
                  View Restaurants Menu
                </Button>
                <Button variant="outline-info" size="sm" className="me-3">
                  Add Restaurants Menu
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      
    </>
  );
};
export default AdminDashboard;
