import React from "react";
import { Row, Col, Container, Card } from "react-bootstrap";
import ItemCard from "../../components/ItemCard.js";
import categories from "../../categories.js";
import cuisines from "../../cuisines.js";
import restaurants from "../../restaurants.js";

const HomePage = () => {
  return (
    <>
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying cuisine names and images */}
         <h4>Check Out Our Great Cuisines</h4>
         <Row>
              {cuisines.map(cuisine=> (
                <Card style={{ width: '12rem' }}>
                <Card.Img variant="top" src={cuisine.image} />
                <Card.Body>
                  <Card.Title>{cuisine.name}</Card.Title>
                  <Card.Text>{cuisine.description}</Card.Text>
                </Card.Body>
              </Card>
              ))}
          </Row>
      </div>
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying category names and images */}
        <h4>Get Inspired By Our Food Categories</h4>
        <Row>
         {categories.map(category=> (
              <Card style={{ width: '12rem' }}>
              <Card.Img variant="top" src={category.image} />
              <Card.Body>
                <Card.Title>{category.name}</Card.Title>
                <Card.Text>{category.description}</Card.Text>
              </Card.Body>
            </Card>
         ))}
         </Row>
      </div>
      <div className="container-fluid">
        {/* Implement Task 1 - Displaying restaurant names and images */}
        <h4>Find Your Restaurants</h4>
        <Row>
         {restaurants.map(restaurant=> (
              <Card style={{ width: '12rem' }}>
              <Card.Img variant="top" src={restaurant.image} />
              <Card.Body>
                <Card.Title>{restaurant.name}</Card.Title>
                <Card.Text>{restaurant.description}</Card.Text>
                <Card.Text>{restaurant.address}</Card.Text>
              </Card.Body>
            </Card>
         ))}
         </Row>
      </div>
    </>
  );
};

export default HomePage;
