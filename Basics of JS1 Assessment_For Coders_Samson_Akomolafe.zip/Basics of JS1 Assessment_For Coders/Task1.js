//1. Create a variable `isHappy` and assign it a boolean value based on the value of the given String variable `action`, whether it is `Smile` or not.

var action = "Smile"
var isHappy = action === "Smile";
// Output the result
console.log(isHappy);


// 2. Create a variable `favoriteSubjects` and assign it an array of strings representing your favorite subjects.
var favoriteSubjects = ["Math", "Science", "History"];
// Output the array
console.log(favoriteSubjects);

// 3. Write a program to compare two numbers, `num1` and `num2`, and check if `num1` is greater than or equal to `num2`.
var num1 = 10;
var num2 = 5;
// Compare the numbers
if (num1 >= num2) {
    console.log("num1 is greater than or equal to num2");
} else {
    console.log("num1 is less than num2");
}

// 4. Write a program to calculate the square of a given number, `num`.

var n = 4;
var square = n * n;
// Output the result
console.log("The square of", n, "is", square);

// 5. Write a program to check if a given number, `num`, is even or odd.

var num_a = 7;
// Check if the number is even or odd
if (num_a % 2 === 0) {
    console.log(num_a + " is even");
} else {
    console.log(num_a + " is odd");
}

// 6. Write a program to check if a given year, `year`, is a leap year and divisible by 400 or divisible by 4 but not divisible by 100.

var year = 2024;
// Check if the year is a leap year
if ((year % 400 === 0) || (year % 4 === 0 && year % 100 !== 0)) {
    console.log(year + " is a leap year");
} else {
    console.log(year + " is not a leap year");
}

// 7. Write a program that checks if a given character, `char`, is a vowel or a consonant.

var char = "a";
// Convert character to lowercase to handle both cases
char = char.toLowerCase();
// Check if the character is a vowel or consonant
if (['a', 'e', 'i', 'o', 'u'].includes(char)) {
    console.log(char + " is a vowel");
} else if (char.match(/[a-z]/i)) {
    console.log(char + " is a consonant");
} else {
    console.log(char + " is not a valid alphabet letter");
}

// 8. Write a program that determines the largest among three numbers, `num1`, `num2`, and `num3`.

var num_1 = 10;
var num_2 = 5;
var num_3 = 8;
function findLargest(num_1, num_2, num_3) {
    if (num_1 >= num_2 && num_1 >= num_3) {
        return num_1;
    } else if (num_2 >= num_1 && num_2 >= num_3) {
        return num_2;
    } else {
        return num_3;
    }
}

var largest = findLargest(num_1, num_2, num_3);
console.log("The largest number is:", largest);


// 9. Write a program that determines the sign of a given number, `num` (positive, negative, or zero), using the ternary operator.

var nu_m = -5;
// Input: You can replace this value with user input if needed
// const num = parseFloat(prompt("Enter a number:"));

const sign = (nu_m > 0) ? "Positive" : (nu_m < 0) ? "Negative" : "Zero";
console.log("The number is:", sign);
 

// 10. Write a program that determines the grade based on a given percentage, `percentage`. Use the following grading scale: A (90-100), B (80-89), C (70-79), D (60-69), F (0-59).

var percentage = 85;
function determineGrade(percentage) {
    let grade;

    if (percentage >= 90 && percentage <= 100) {
        grade = 'A';
    } else if (percentage >= 80 && percentage < 90) {
        grade = 'B';
    } else if (percentage >= 70 && percentage < 80) {
        grade = 'C';
    } else if (percentage >= 60 && percentage < 70) {
        grade = 'D';
    } else if (percentage >= 0 && percentage < 60) {
        grade = 'F';
    } else {
        grade = 'Invalid percentage';
    }

    return grade;
}

// Input: You can replace this value with user input if needed
// const percentage = parseFloat(prompt("Enter the percentage:"));

const grade = determineGrade(percentage);
console.log("The grade is:", grade);
