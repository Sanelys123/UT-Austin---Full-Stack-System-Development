// 1. Write a program that determines the type of triangle based on the lengths of its sides (`side1`, `side2`, and `side3`). The types of triangles are equilateral, isosceles, and scalene.

var side1 = 5;
var side2 = 5;
var side3 = 8;
function determineTriangleType(side1, side2, side3) {
  if (side1 <= 0 || side2 <= 0 || side3 <= 0) {
      return "Invalid side lengths";
  }

  if (side1 === side2 && side2 === side3) {
      return "Equilateral";
  } else if (side1 === side2 || side1 === side3 || side2 === side3) {
      return "Isosceles";
  } else {
      return "Scalene";
  }
}

var triangleType = determineTriangleType(side1, side2, side3);
console.log("The triangle is:", triangleType);


// 2. Write a JavaScript program that counts the number of occurrences of a specific element in an array using a for...of loop.

var arr = [1, 2, 3, 4, 2, 5, 2, 6];
var target = 2;
function countOccurrences(arr, target) {
    let count = 0;

    for (const item of arr) {
        if (item === target) {
            count++;
        }
    }

    return count;
}
var noOfTimes = countOccurrences(arr, target);
console.log(`The element ${target} occurs ${noOfTimes} times in the array.`);
 //COMPLETE THE CODE HERE
  
var numbers = [1, 2, 3, 2, 4, 2, 5];
console.log(countOccurrences(numbers, 2)); 


// 3. Write a function that takes an array of product prices and returns the total price. 
//You can assume that the array contains only numbers.

function calculateTotalPrice(prices) {
  let total = 0;

  for (const price of prices) {
      total += price;
  }

  return total;
}

// Example array of product prices
var productprices = [10, 20, 30, 40];

var totalPrice = calculateTotalPrice(productprices);
console.log("The total price is:", totalPrice);


// 4. Write a function that takes an array of product prices and a discount percentage. 
//Apply the discount to each product price and return the updated prices as an array.

function applyDiscount(prices, discount) {
  var discountedPrices = [];

  for (const price of prices) {
      var discountAmount = price * (discount / 100);
      var newPrice = price - discountAmount;
      discountedPrices.push(newPrice);
  }

  return discountedPrices;
}

// Example array of product prices and discount percentage
var productPrices = [10, 20, 30, 40];
var discount = 20; // 20%

var updatedPrices = applyDiscount(productPrices, discount);
console.log("Updated prices after discount:", updatedPrices);


// 5. Write a function that takes an array of product quantities and 
//returns an array of indices for products that are out of stock (quantity is 0).

function getOutOfStockProducts(quantities) {
  const outOfStockIndices = [];

  for (let i = 0; i < quantities.length; i++) {
      if (quantities[i] === 0) {
          outOfStockIndices.push(i);
      }
  }

  return outOfStockIndices;
}

// Example usage:
var quantities = [2, 0, 4, 0, 3];
var outOfStock = getOutOfStockProducts(quantities);
console.log(getOutOfStockProducts(quantities)); 
console.log("Out of stock products:", outOfStock);


// 6. Print the multiplication table of 7
// It should be in the format: 
// 7 * 1 = 7

function MultiplicationTableOf7() {
  var number = 7;

  for (let i = 1; i <= 24; i++) {
      console.log(`${number} * ${i} = ${number * i}`);
  }
}

MultiplicationTableOf7();


// 7. Create a function to calculate factorial of a number.
// Assume that the input is an integer
// Example: Factorial of 5 = 120

function calculateFactorial(n) {

  if (n < 0) {
      return "Factorial is not defined for negative numbers.";
  }
  if (n === 0 || n === 1) {
      return 1;
  }

  var result = 1;
  for (let i = 2; i <= n; i++) {
      result *= i;
  }

  return result;
}

// Example usage
var number = 0; // Change this to calculate factorial of a different number
var result = calculateFactorial(number);
console.log(`The factorial of ${number} is:`, result);

// Example Usage
console.log(calculateFactorial(1)); 
console.log(calculateFactorial(2)); 
console.log(calculateFactorial(3)); 
console.log(calculateFactorial(4)); 
console.log(calculateFactorial(5)); 
console.log(calculateFactorial(-1)); 


// 8. Create a function to generate fibonacci series. 
// Fibonacci Series is a sequence of numbers in which each number is the sum of the two preceding ones. It starts with 0 and 1.
// The number of terms of the series should be passed as argument to the function.
// Example: Fibonacci series of 5 terms => 0 1 1 2 3 
// Assume that the inputs are positive integers

function generateFibonacciSeries(numTerms) {
    var fibonacciSeries = [];
  
    if (numTerms <= 0) {
        return "Below is the fibonacci of 0,1,2,3,4,5";
    }
  
    // Start with the first two Fibonacci numbers
    fibonacciSeries[0] = 0;
    if (numTerms > 1) {
        fibonacciSeries[1] = 1;
    }
  
    for (let i = 2; i < numTerms; i++) {
        fibonacciSeries[i] = fibonacciSeries[i - 1] + fibonacciSeries[i - 2];
    }
  
    return fibonacciSeries;
  }
  
// Example Usage
console.log(generateFibonacciSeries(0)); 
console.log(generateFibonacciSeries(1));  
console.log(generateFibonacciSeries(2));
console.log(generateFibonacciSeries(3));
console.log(generateFibonacciSeries(4));  
console.log(generateFibonacciSeries(5));  


// 9. Create a function to print a star-pattern triangle 
// The function should take number of rows as an argument
// Assume that the argument passed is a positive integer
// The pattern should appear as follows for input = 5
// *
// * *
// * * *
// * * * *
// * * * * *

function printTriangle(rows) {
    for (let i = 1; i <= rows; i++) {
      let stars = '';

      // Add stars for the current row
      for (let j = 1; j <= i; j++) {
          stars += '* ';
      }

      console.log(stars);
  }
}
// Example usage
const numberOfRows = 5; // Change this to print a triangle with more or fewer rows
printTriangle(numberOfRows);


// 10. Create a function to reverse a string. 
// Pass a string as an argument.
// Assume that the argument is always a string.

function reverseString(inputString) {
  var reversed = '';
  
    for (let i = inputString.length - 1; i >= 0; i--) {
        reversed += inputString[i];
    }
  
    return reversed;
  }

// Example Usage
console.log(reverseString("Hello, World!"));
console.log(reverseString("Great Learning")); 
console.log(reverseString("University of Texas At Austin"));   
console.log(reverseString("0123455789"));         
console.log(reverseString(""));               






       
